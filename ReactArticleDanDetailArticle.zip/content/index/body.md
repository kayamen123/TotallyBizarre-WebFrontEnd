---
# You don’t need to declare anything in the frontmatter
---

This is a demo page to get you running asap.