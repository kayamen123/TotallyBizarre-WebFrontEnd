import React from 'react';
import PropTypes, { string } from 'prop-types';

function Question(props) {
  return (
    <div>
    <h2 className="question">{props.content.content}</h2>
    <img src={props.content.imgurl}/>
    </div>
  );
}

Question.propTypes = {
  content: PropTypes.objectOf({content:string,imgurl:string}).isRequired
};

export default Question;