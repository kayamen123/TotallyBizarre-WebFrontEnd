import React from 'react';
import PropTypes from 'prop-types';
import { CSSTransitionGroup } from 'react-transition-group';

function Result(props) {
    let {quizResult}=props;
    let img = "";
    if(quizResult === "Microsoft"){
      img="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.egrabber.com%2Fassets%2Fimg%2Fegrabber%2Fcustomers%2Fmicrosoft.png&f=1&nofb=1";
    }else if(quizResult === "Sony"){
      img="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.allround-pc.com%2Fwp-content%2Fuploads%2F2013%2F02%2FSony_Logo.png&f=1&nofb=1";
    }else if(quizResult === "Nintendo"){
      img="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.vectorsland.com%2Fimgd%2Fs21459-nintendo-logo-45296.png&f=1&nofb=1";
    }else{
      img="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fcdn3.iconfinder.com%2Fdata%2Ficons%2Fpassword-1%2F128%2Fforget_password_forgot_password_missing_forgetting_confuse-128.png&f=1&nofb=1"
    }
    
    return (
        <CSSTransitionGroup
          className="container result"
          component="div"
          transitionName="fade"
          transitionEnterTimeout={800}
          transitionLeaveTimeout={500}
          transitionAppear
          transitionAppearTimeout={500}
        >
          <div className="container-quiz">
            You prefer <strong>{props.quizResult}</strong>!
            <img src= {img} />
          </div>
        </CSSTransitionGroup>
      );
}

Result.propTypes = {
  quizResult: PropTypes.string.isRequired,
};

export default Result;